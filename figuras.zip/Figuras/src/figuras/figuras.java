/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figuras;

/**
 *
 * @author Lab
 */
public class figuras {

    /**
     * @param args the command line arguments
     */
    public static void figuras(String[] args) {
        // TODO code application logic here
    }
    
}
