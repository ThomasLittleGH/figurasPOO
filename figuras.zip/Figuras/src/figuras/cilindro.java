/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figuras;

/**
 *
 * @author Lab
 */
public class cilindro extends circulo{
    //defino variable
    private double altura;
    //Super se refierea la superclase de circulo, es decir super() es igual al circulo();
    
    public cilindro() {
        super();
        altura = 1;
    }

    public cilindro(double altura) {
        this.altura = altura;
    }

    public cilindro(double radio, double altura) {
        super(radio);
        this.altura = altura;
    }

    public double getAltura() {
        return altura;
    }

    public void setAltura(double altura) {
        this.altura = altura;
    }
    
    public double getVolumen(double altura){
        return super.getArea() * altura;
    }

    @Override
    public String toString() {
        return "cilindro, subclase de " + super.toString() + " { altura=" + altura + '}';
    }
    
}
