/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package figuras;

/**
 *
 * @author Lab
 */
public class circulo {
    //Instanciar variables o atributos
    private double radio;
    private String color;
    
    //Generar constructores
    public circulo(){ //constructor por defaut, no recibe parametros
        radio = 1;
        color = "rojo";
    }
    
    public circulo(double radio){// constructor que recibe solo un parametro
        this.radio = radio;
        color= "rojo";
    }
    
    public circulo(double radio, String color){//constructor que recibe ambos radio y color
        this.radio = radio;
        this.color = color;
    }

    public double getRadio() {
        return radio;
    }

    public void setRadio(double radio) {
        this.radio = radio;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }
    
    public double getArea(){
        return radio * radio * Math.PI;
    }

    @Override
    public String toString() {
        return "circulo{" + "radio=" + radio + ", color=" + color + '}';
    }

}
